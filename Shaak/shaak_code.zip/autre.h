/*
Fichier cr�� le 21/01/2012 � 19h05

-----------------------------------------------------------------

Fichier cr�� par tsunami33 pour le projet shaak

-----------------------------------------------------------------

Fichier header regroupant les fonctions permettant d'am�liorer la fonction scanf.
Il regroupe aussi les fonstions de gestion du son.
*/

#ifndef DEF_AUTRE
    #define DEF_AUTRE

    #include "constantes.h"
    #ifdef WINDOWS
        #include <windows.h>
    #endif

    void cls(); //Efface la console
    int color(WORD theColor); //permet de changer la couleur d'�criture et de fond
    int wantSound(); //Demande � l'utilisateur s'il veut du son ou non
    void musicPlay(char* nomMusique, int nbTotalMusics); //Joue une musique si le son est activ�
    int powInt(const int nb1, int nb2); //Calcule nb1 puissance nb2 et renvoie le r�sultat
    void viderBuffer(); //Vide le buffer pour scans()
    int scans(char *chaine, int longueur); //Demande une cha�ne de caract�re
    void scand(int *var); //Demande un nombre entier
    void scanc(char* caractere); //Demande un caract�re
    void wscanc(wchar_t* caractere); //Demande un caract�re (accents possibles)
    void ecrire(const wchar_t *text, ...); //Permet d'�crire avec des couleurs

    typedef struct Music Music;
    struct Music
    {
        short int isMusic;
        FMOD_SYSTEM **systeme;
        FMOD_CHANNELGROUP **channel;
        FMOD_SOUND **musique;
    };

    enum Color
    {
        Black        = 0,
        Grey         = FOREGROUND_INTENSITY,
        LightGrey    = FOREGROUND_RED   | FOREGROUND_GREEN | FOREGROUND_BLUE,
        White        = FOREGROUND_RED   | FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_INTENSITY,
        Blue         = FOREGROUND_BLUE,
        Green        = FOREGROUND_GREEN,
        Cyan         = FOREGROUND_GREEN | FOREGROUND_BLUE,
        Red          = FOREGROUND_RED,
        Purple       = FOREGROUND_RED   | FOREGROUND_BLUE,
        LightBlue    = FOREGROUND_BLUE  | FOREGROUND_INTENSITY,
        LightGreen   = FOREGROUND_GREEN | FOREGROUND_INTENSITY,
        LightCyan    = FOREGROUND_GREEN | FOREGROUND_BLUE  | FOREGROUND_INTENSITY,
        LightRed     = FOREGROUND_RED   | FOREGROUND_INTENSITY,
        LightPurple  = FOREGROUND_RED   | FOREGROUND_BLUE  | FOREGROUND_INTENSITY,
        Orange       = FOREGROUND_RED   | FOREGROUND_GREEN,
        Yellow       = FOREGROUND_RED   | FOREGROUND_GREEN | FOREGROUND_INTENSITY,
        BBlack       = 0,
        BGrey        = BACKGROUND_INTENSITY,
        BLightGrey   = BACKGROUND_RED   | BACKGROUND_GREEN | BACKGROUND_BLUE,
        BWhite       = BACKGROUND_RED   | BACKGROUND_GREEN | BACKGROUND_BLUE | BACKGROUND_INTENSITY,
        BBlue        = BACKGROUND_BLUE,
        BGreen       = BACKGROUND_GREEN,
        BCyan        = BACKGROUND_GREEN | BACKGROUND_BLUE,
        BRed         = BACKGROUND_RED,
        BPurple      = BACKGROUND_RED   | BACKGROUND_BLUE,
        BLightBlue   = BACKGROUND_BLUE  | BACKGROUND_INTENSITY,
        BLightGreen  = BACKGROUND_GREEN | BACKGROUND_INTENSITY,
        BLightCyan   = BACKGROUND_GREEN | BACKGROUND_BLUE  | BACKGROUND_INTENSITY,
        BLightRed    = BACKGROUND_RED   | BACKGROUND_INTENSITY,
        BLightPurple = BACKGROUND_RED   | BACKGROUND_BLUE  | BACKGROUND_INTENSITY,
        BOrange      = BACKGROUND_RED   | BACKGROUND_GREEN,
        BYellow      = BACKGROUND_RED   | BACKGROUND_GREEN | BACKGROUND_INTENSITY,
    };

#endif
